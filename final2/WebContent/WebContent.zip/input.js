"use strict";

(function() {
	let start;
	let end;
	let flag=0;
	
   window.onload = function() {
      let el = document.getElementById("ha");
      el.addEventListener("click", showElement); 
      let el1 = document.getElementById("ha1");
      el1.addEventListener("click", showElement);
      let el2 = document.getElementById("ha2");
      el2.addEventListener("click", showElement);
      let el3 = document.getElementById("ha3");
      el3.addEventListener("click", showElement);
      let el4 = document.getElementById("ha4");
      el4.addEventListener("click", showElement);
      let el5 = document.getElementById("ha5");
      el5.addEventListener("click", showElement);
      
      let el6 = document.getElementById("ha6");
      el6.addEventListener("click", showElement);
      let el7 = document.getElementById("ha7");
      el7.addEventListener("click", showElement);
      let el8 = document.getElementById("ha8");
      el8.addEventListener("click", showElement);
      let el9 = document.getElementById("ha9");
      el9.addEventListener("click", showElement);
      let el10 = document.getElementById("ha10");
      el10.addEventListener("click", showElement);
      
      let el11 = document.getElementById("ha11");
      el11.addEventListener("click", showElement);
      let el12 = document.getElementById("ha12");
      el12.addEventListener("click", showElement);
      let el13 = document.getElementById("ha13");
      el13.addEventListener("click", showElement);
      let el14 = document.getElementById("ha14");
      el14.addEventListener("click", showElement);
      let el15 = document.getElementById("ha15");
      el15.addEventListener("click", showElement);
      
      let el16 = document.getElementById("ha16");
      el16.addEventListener("click", showElement);
      let el17 = document.getElementById("ha17");
      el17.addEventListener("click", showElement);
      let el18 = document.getElementById("ha18");
      el18.addEventListener("click", showElement);
      let el19 = document.getElementById("ha19");
      el19.addEventListener("click", showElement);
      let el20 = document.getElementById("ha20");
      el20.addEventListener("click", showElement);
      
      let el21 = document.getElementById("ha21");
      el21.addEventListener("click", showElement);
      let el22 = document.getElementById("ha22");
      el22.addEventListener("click", showElement);
      let el23 = document.getElementById("ha23");
      el23.addEventListener("click", showElement);
      let el24 = document.getElementById("ha24");
      el24.addEventListener("click", showElement);
      let el25 = document.getElementById("ha25");
      el25.addEventListener("click", showElement);
      
      let el26 = document.getElementById("ha26");
      el26.addEventListener("click", showElement);
      let el27 = document.getElementById("ha27");
      el27.addEventListener("click", showElement);
      let el28 = document.getElementById("ha28");
      el28.addEventListener("click", showElement);
      let el29 = document.getElementById("ha29");
      el29.addEventListener("click", showElement);
      let el30 = document.getElementById("ha30");
      el30.addEventListener("click", showElement);
      
      let el31 = document.getElementById("ha31");
      el31.addEventListener("click", showElement);
      let el32 = document.getElementById("ha32");
      el32.addEventListener("click", showElement);
      let el33 = document.getElementById("ha33");
      el33.addEventListener("click", showElement);
      let el34 = document.getElementById("ha34");
      el34.addEventListener("click", showElement);
      let el35 = document.getElementById("ha35");
      el35.addEventListener("click", showElement);
      
      let el36 = document.getElementById("ha36");
      el36.addEventListener("click", showElement);
      let el37 = document.getElementById("ha37");
      el37.addEventListener("click", showElement);
      let el38 = document.getElementById("ha38");
      el38.addEventListener("click", showElement);
      let el39 = document.getElementById("ha39");
      el39.addEventListener("click", showElement);
      let el40 = document.getElementById("ha40");
      el40.addEventListener("click", showElement);
      
      let el41 = document.getElementById("ha41");
      el41.addEventListener("click", showElement);
      let el42 = document.getElementById("ha42");
      el42.addEventListener("click", showElement);
      let el43 = document.getElementById("ha43");
      el43.addEventListener("click", showElement);
      let el44 = document.getElementById("ha44");
      el44.addEventListener("click", showElement);
      let el45 = document.getElementById("ha45");
      el45.addEventListener("click", showElement);
      
      let el46 = document.getElementById("ha46");
      el46.addEventListener("click", showElement);
      let el47 = document.getElementById("ha47");
      el47.addEventListener("click", showElement);
      let el48 = document.getElementById("ha48");
      el48.addEventListener("click", showElement);
      
   }
   
   function showElement() {
	   if(flag==0)
		   {
			   start= this.name;
		       alert("Start station : " +start);
		       flag=1;
		   }
	   else if(flag==1)
		   {
			   end= this.name;
		       alert("End station : " +end);
	       	   flag=0;
		   }
   }
   
})();